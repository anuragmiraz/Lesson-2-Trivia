import os
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random
# My change starts
import sys
# My change ends
from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10

# My change starts

# Defining pagination logic function
def paginate_questions(request, selection):

    page = request.args.get('page', 1, type=int)
    start = (page - 1) * QUESTIONS_PER_PAGE
    end = start + QUESTIONS_PER_PAGE
    
    questions_formatting = [question.format() for question in selection]
    current_questions = questions_formatting[start:end]
    return current_questions

# Category formatting function
def get_category_list():
  
  categories = {}
  catg_query = Category.query.all()
  
  for category in catg_query:
    categories[category.id] = category.type
  
  return categories
# My change ends

def create_app(test_config=None):
  # create and configure the app
  app = Flask(__name__)
  setup_db(app)
  
  '''
  @TODO: Set up CORS. Allow '*' for origins. Delete the sample route after completing the TODOs
  '''
# My change starts
  CORS(app, resources={r"/*": {"origins": '*'}})
#  My change ends

  '''
  @TODO: Use the after_request decorator to set Access-Control-Allow
  '''
# My change starts
  @app.after_request
  def after_request(response):
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type, Authorisation,true')
    response.headers.add('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS')
    return response
# My change ends

  '''
  @TODO: 
  Create an endpoint to handle GET requests 
  for all available categories.
  '''
# My change starts
  @app.route('/categories', methods=['GET'])
  def get_categories():

    try:

      catg_output = Category.query.order_by(Category.id).all()

      if len(catg_output) == 0:
        abort(404)
      else:
        return jsonify({
          'success': True,
          'categories': get_category_list()
          }),200

    except:
      abort(400)
# My change ends

  '''
  @TODO: 
  Create an endpoint to handle GET requests for questions, 
  including pagination (every 10 questions). 
  This endpoint should return a list of questions, 
  number of total questions, current category, categories. 

  TEST: At this point, when you start the application
  you should see questions and categories generated,
  ten questions per page and pagination at the bottom of the screen for three pages.
  Clicking on the page numbers should update the questions. 
  '''

# My change starts
  @app.route('/questions', methods=['GET'])
  def display_questions():
  
    try:
  
      selection = Question.query.order_by(Question.id).all()
      current_questions = paginate_questions(request, selection)

      if len(current_questions) == 0:
        abort(404)
      else:
        return jsonify({
          'success': True,
          'questions': current_questions,
          'total_questions': len(selection),
          'categories': get_category_list(),
          'currentCategory': None
          }),200

    except:
      abort(400)
# My change ends

  '''
  @TODO: 
  Create an endpoint to DELETE question using a question ID. 

  TEST: When you click the trash icon next to a question, the question will be removed.
  This removal will persist in the database and when you refresh the page. 
  '''

# My change starts
  @app.route('/questions/<int:id>', methods=['DELETE'])
  def delete_question(id):
    
    question = Question.query.filter(Question.id==id).one_or_none()
    
    if question is None:
      abort(404)
    else:   
      question.delete()
      return jsonify({
        'success': True,
        'deleted_id': id
        }),200
# My change ends

  '''
  @TODO: 
  Create an endpoint to POST a new question, 
  which will require the question and answer text, 
  category, and difficulty score.

  TEST: When you submit a question on the "Add" tab, 
  the form will clear and the question will appear at the end of the last page
  of the questions list in the "List" tab.  
  '''

# My change starts
  @app.route('/questions', methods=['POST'])
  def create_question():
    
    new_question = request.json.get('question', None)
    new_answer = request.json.get('answer', None)
    new_category = request.json.get('category', None)
    new_difficulty = request.json.get('difficulty', 0)

    if new_question is None:
      abort(422)
    if new_answer is None:
      abort(422)
    if new_category is None:
      abort(422)

    questions = Question(question=new_question, answer=new_answer, category=new_category, difficulty=new_difficulty)
    questions.insert()
            
    return jsonify({
      'success': True,
      'Question id': questions.id
      }),200
# My change starts

  '''
  @TODO: 
  Create a POST endpoint to get questions based on a search term. 
  It should return any questions for whom the search term 
  is a substring of the question. 

  TEST: Search by any phrase. The questions list will update to include 
  only question that include that string within their question. 
  Try using the word "title" to start. 
  '''

# My change starts
  @app.route('/questions/search', methods=['POST'])
  def search_question():
    
    input_data = request.json.get('searchTerm', '')
      
    selection = Question.query.filter(Question.question.ilike('%' + input_data + '%')).all()
    current_questions = paginate_questions(request, selection)
      
    if len(selection) == 0:
      abort(404)
    else:
      return jsonify({
        'success': True,
        'questions': current_questions,
        'total_questions': len(selection),
        'currentCategory': None
        }),200
# My change ends

  '''
  @TODO: 
  Create a GET endpoint to get questions based on category. 

  TEST: In the "List" tab / main screen, clicking on one of the 
  categories in the left column will cause only questions of that 
  category to be shown. 
  '''

# My change starts
  @app.route('/categories/<int:id>/questions', methods=['GET'])
  def get_catg_questions(id):
    
    question_output = Question.query.filter(Question.category == str(id)).all()
    total_questions = Question.query.all()

    if len(question_output) == 0:
      abort(404)
    else:
      return jsonify({
        'success': True,
        'questions' : [question.format() for question in question_output],
        'totalQuestions': len(total_questions),
        'currentCategory': None
        }),200
# My change ends

  '''
  @TODO: 
  Create a POST endpoint to get questions to play the quiz. 
  This endpoint should take category and previous question parameters 
  and return a random questions within the given category, 
  if provided, and that is not one of the previous questions. 

  TEST: In the "Play" tab, after a user selects "All" or a category,
  one question at a time is displayed, the user is allowed to answer
  and shown whether they were correct or not. 
  '''

# My change starts
  @app.route('/quizzes', methods=['POST'])
  def play_quiz():
    inp_prev_quest = request.json.get('previous_questions', [])
    inp_quiz_catg  = request.json.get('quiz_category', 0)
      
    if inp_quiz_catg['id'] == 0:
      quiz_question = Question.query.filter(Question.id.notin_(inp_prev_quest)).all()
    else:
      quiz_question = Question.query.filter(Question.category == inp_quiz_catg['id']).filter(Question.id.notin_(inp_prev_quest)).all()

    try:
      formatted_quiz_question = random.choice(quiz_question).format()
 
    except:
      abort(422)

    return jsonify({
      'success': True,
      'question': formatted_quiz_question
      }),200


# My change ends

  '''
  @TODO: 
  Create error handlers for all expected errors 
  including 404 and 422. 
  '''
  
# M y change starts
  @app.errorhandler(400)
  def bad_request(error):
    return jsonify({
      "success": False,
      "error": 400,
      "message": 'bad request'      
      }), 400

  @app.errorhandler(404)
  def not_found(error):
    return jsonify({
      "success": False,
      "error": 404,
      "message": 'resource not found'
      }), 404

  @app.errorhandler(422)
  def unprocessable(error):
    return jsonify({
      "success": False,
      "error": 422,
      "message": 'unprocessable'
      }), 422
# My chnage ends
     
  return app